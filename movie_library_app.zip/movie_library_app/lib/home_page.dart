import 'package:flutter/material.dart';
import 'movie.dart';
import 'movie_card.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool isGrid = false; // false = list, true = grid
  String searchText = ''; // saved from TextField.onChanged
  int discount = 20; // BONUS: lives here so every card sees the same value

  void decreaseDiscount() {
    setState(() {
      if (discount > 0) discount--;
    });
  }

  @override
  Widget build(BuildContext context) {
    final query = searchText.trim().toLowerCase();

    final List<Movie> filteredMovies = movies.where((movie) {
      return movie.title.toLowerCase().contains(query) ||
          movie.genre.toLowerCase().contains(query);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Movie Library'),
        actions: [
          IconButton(
            icon: Icon(isGrid ? Icons.view_list : Icons.grid_view),
            onPressed: () {
              setState(() {
                isGrid = !isGrid;
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  searchText = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Search movies...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          Expanded(
            child: filteredMovies.isEmpty
                ? const Center(child: Text('No movies found'))
                : isGrid
                    ? GridView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.65,
                        ),
                        itemCount: filteredMovies.length,
                        itemBuilder: (context, index) {
                          return MovieCard(
                            movie: filteredMovies[index],
                            discount: discount,
                            onDiscountTap: decreaseDiscount,
                          );
                        },
                      )
                    : ListView.builder(
                        itemCount: filteredMovies.length,
                        itemBuilder: (context, index) {
                          return SizedBox(
                            height: 340,
                            child: MovieCard(
                              movie: filteredMovies[index],
                              discount: discount,
                              onDiscountTap: decreaseDiscount,
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
