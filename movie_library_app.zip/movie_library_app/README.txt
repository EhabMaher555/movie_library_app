Movie Library App - how to use

1. Run:  flutter create movie_library_app   (or use your existing project)
2. Copy the lib/ folder from this zip over your project's lib/ folder.
3. Copy the assets/ folder into the project root and add the 8 poster images.
4. Open pubspec_assets_snippet.yaml and copy the assets lines into your pubspec.yaml.
5. Run:  flutter pub get   then   flutter run
6. Do NOT upload the build/ folder to GitHub.
